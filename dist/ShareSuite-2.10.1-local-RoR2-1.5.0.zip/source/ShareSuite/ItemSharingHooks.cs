using EntityStates.Scrapper;
using MonoMod.Cil;
using R2API.Utils;
using RewiredConsts;
using RoR2;
using ShareSuite.Networking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.Networking;
using Random = UnityEngine.Random;

namespace ShareSuite
{
    public static class ItemSharingHooks
    {
        private static bool _itemLock = false;

        private static readonly List<CostTypeIndex> PrinterCosts = new List<CostTypeIndex>
        {
            CostTypeIndex.WhiteItem,
            CostTypeIndex.GreenItem,
            CostTypeIndex.RedItem,
            CostTypeIndex.BossItem,
            CostTypeIndex.LunarItemOrEquipment
        };

        public static void UnHook()
        {
            On.RoR2.PurchaseInteraction.OnInteractionBegin -= OnShopPurchase;
            On.RoR2.ShopTerminalBehavior.DropPickup_bool -= OnPurchaseDrop;
            On.RoR2.GenericPickupController.AttemptGrant -= OnGrantItem;
            On.EntityStates.ScavBackpack.Opening.OnEnter -= OnScavengerDrop;
            On.RoR2.Chat.PlayerPickupChatMessage.ConstructChatString -= FixZeroItemCount;
            // On.EntityStates.Scrapper.ScrappingToIdle.OnEnter -= ScrappingToIdle_OnEnter;
            // On.RoR2.PickupCatalog.FindPickupIndex_string -= ItemLock;

            IL.RoR2.ArenaMissionController.EndRound -= ArenaDropEnable;
            IL.RoR2.InfiniteTowerWaveController.DropRewards -= SimulacrumArenaDropEnable;
            //IL.RoR2.GenericPickupController.AttemptGrant -= RemoveDefaultPickupMessage;
        }

        public static void Hook()
        {
            Log.Debug("Sharesuite: Hooking itemsharing");
            On.RoR2.PurchaseInteraction.OnInteractionBegin += OnShopPurchase;
            On.RoR2.ShopTerminalBehavior.DropPickup_bool += OnPurchaseDrop;
            On.RoR2.GenericPickupController.AttemptGrant += OnGrantItem;
            On.EntityStates.ScavBackpack.Opening.OnEnter += OnScavengerDrop;
            On.RoR2.Chat.PlayerPickupChatMessage.ConstructChatString += FixZeroItemCount;
            // On.EntityStates.Scrapper.ScrappingToIdle.OnEnter += ScrappingToIdle_OnEnter;
            // On.RoR2.PickupCatalog.FindPickupIndex_string += ItemLock;

            if (ShareSuite.OverrideVoidFieldLootScalingEnabled.Value)
            {
                IL.RoR2.ArenaMissionController.EndRound += ArenaDropEnable;
                IL.RoR2.InfiniteTowerWaveController.DropRewards += SimulacrumArenaDropEnable;
            }

            //if (ShareSuite.RichMessagesEnabled.Value) IL.RoR2.GenericPickupController.AttemptGrant += RemoveDefaultPickupMessage;
        }

        // private static PickupIndex ItemLock(On.RoR2.PickupCatalog.orig_FindPickupIndex_string orig, string pickupName)
        // {
        //     // This is a bit of a dubious hook, but it enables really nice interaction with the scrapper, where we add
        //     // an item every time the scrapper finishes its animation.

        //     #region Cauldronfix

        //     if (_itemLock)
        //     {
        //         _itemLock = false;
        //         return orig("This is not an item!");
        //     }

        //     return orig(pickupName);

        //     #endregion
        // }

        // private static void ScrappingToIdle_OnEnter(On.EntityStates.Scrapper.ScrappingToIdle.orig_OnEnter orig,
        //     ScrappingToIdle self)
        // {
        //     if (!(ShareSuite.PrinterCauldronFixEnabled.Value && NetworkServer.active && GeneralHooks.IsMultiplayer()))
        //     {
        //         orig(self);
        //         return;
        //     }

        //     _itemLock = true;
        //     orig(self);

        //     var scrapperController =
        //         GetInstanceField(typeof(ScrapperBaseState), self, "scrapperController") as ScrapperController;

        //     Log.Debug(scrapperController);
        //     Log.Debug(_itemLock);
        //     if (scrapperController)
        //     {
        //         var pickupIndex = PickupIndex.none;
        //         var itemDef = ItemCatalog.GetItemDef((ItemIndex) GetInstanceField(typeof(ScrapperController),
        //             scrapperController, "_lastScrappedItemIndex"));
        //         if (itemDef != null)
        //         {
        //             switch (itemDef.tier)
        //             {
        //                 case ItemTier.Tier1:
        //                     pickupIndex = PickupCatalog.FindPickupIndex("ItemIndex.ScrapWhite");
        //                     break;
        //                 case ItemTier.Tier2:
        //                     pickupIndex = PickupCatalog.FindPickupIndex("ItemIndex.ScrapGreen");
        //                     break;
        //                 case ItemTier.Tier3:
        //                     pickupIndex = PickupCatalog.FindPickupIndex("ItemIndex.ScrapRed");
        //                     break;
        //                 case ItemTier.Boss:
        //                     pickupIndex = PickupCatalog.FindPickupIndex("ItemIndex.ScrapYellow");
        //                     break;
        //             }
        //         }

        //         if (pickupIndex == PickupIndex.none) return;

        //         var interactor =
        //             GetInstanceField(typeof(ScrapperController), scrapperController, "interactor") as Interactor;
        //         Log.Debug("Interactor Established");

        //         var pickupDef = PickupCatalog.GetPickupDef(pickupIndex);

        //         if (!interactor) return;

        //         SetInstanceField(typeof(ScrappingToIdle), self, "foundValidScrap", true);
        //         var component = interactor.GetComponent<CharacterBody>();
        //         HandleGiveItem(component.master, pickupDef);
        //         ChatHandler.SendRichCauldronMessage(component.inventory.GetComponent<CharacterMaster>(), pickupIndex);

        //         var itemsEaten = (int) GetInstanceField(typeof(ScrapperController), scrapperController, "_itemsEaten");
        //         SetInstanceField(typeof(ScrapperController), scrapperController, "_itemsEaten", itemsEaten - 1);
        //     }
        // }

        private static void OnGrantItem(On.RoR2.GenericPickupController.orig_AttemptGrant orig,
            GenericPickupController self, CharacterBody body)
        {
            // RoR2 1.5 rental items use GiveItemRented. Sharing through GiveItem
            // would incorrectly turn them into permanent items for teammates.
            if (self.pickup.isRental)
            {
                orig(self, body);
                return;
            }

            var item = PickupCatalog.GetPickupDef(self.pickupIndex);
            var itemDef = ItemCatalog.GetItemDef(item.itemIndex);
            var randomizedPlayerDict = new Dictionary<CharacterMaster, PickupDef>();

            // If the player is dead, they might not have a body. The game uses inventory.GetComponent, avoiding the issue entirely.
            var master = body?.master ?? body.inventory?.GetComponent<CharacterMaster>();

            if (!Blacklist.HasItem(item.itemIndex)
                && NetworkServer.active
                && IsValidItemPickup(self.pickupIndex)
                && IsValidPickupObject(self, body)
                && GeneralHooks.IsMultiplayer()
                && !self.pickup.isTempItem) // Don't share the item with anyone else if the item is temporary
            {
                if (ShareSuite.RandomizeSharedPickups.Value)
                {
                    randomizedPlayerDict.Add(master, item);
                }

                foreach (var player in PlayerCharacterMasterController.instances
                             .Select(p => p.master))
                {
                    // Do not reward dead players if not required
                    if (!ShareSuite.DeadPlayersGetItems.Value && IsDeadAndNotADrone(player)) continue;

                    // Do not give an additional item to the player who picked it up.
                    if (player.inventory == body.inventory)
                    {
                        // Do not send the message to unlock if it's the local player.
                        if (player.isLocalPlayer)
                        {
                            continue;
                        }

                        NetworkHandler.SendItemPickupMessage(
                            player.playerCharacterMasterController.networkUser.connectionToClient.connectionId,
                            item.pickupIndex);

                        continue;
                    }

                    if (ShareSuite.RandomizeSharedPickups.Value)
                    {
                        var pickupIndex = GetRandomItemOfTier(itemDef.tier, item.pickupIndex);
                        if (pickupIndex == null)
                        {
                            // Could not find any not blacklisted item in that tier. You get nothing! Good day, sir!
                            continue;
                        }

                        var giveItem = PickupCatalog.GetPickupDef(pickupIndex.Value);

                        HandleGiveItem(player, giveItem);
                        // Alternative: Only show pickup text for yourself
                        // var givePickupDef = PickupCatalog.GetPickupDef(givePickupIndex);
                        // Chat.AddPickupMessage(body, givePickupDef.nameToken, givePickupDef.baseColor, 1);

                        // Legacy -- old normal pickup message handler
                        //SendPickupMessage(player, giveItem);

                        randomizedPlayerDict.Add(player, giveItem);
                    }
                    // Otherwise give everyone the same item
                    else
                    {
                        HandleGiveItem(player, item);
                    }
                }

                if (ShareSuite.RandomizeSharedPickups.Value)
                {
                    orig(self, body);
                    ChatHandler.SendRichRandomizedPickupMessage(master, item, randomizedPlayerDict,
                        self.pickup.isTempItem);
                    return;
                }
            }

            orig(self, body);

            ChatHandler.SendRichPickupMessage(master, item, self.pickup.isTempItem);

            // ReSharper disable once PossibleNullReferenceException
            HandleRichMessageUnlockAndNotification(master, item.pickupIndex);
        }

        public static bool IsDeadAndNotADrone(CharacterMaster master)
        {
            if (master == null || master.GetBody() == null) return true;
            return master.IsDeadAndOutOfLivesServer() && !master.GetBody().IsDrone;
        }

        private static string FixZeroItemCount(On.RoR2.Chat.PlayerPickupChatMessage.orig_ConstructChatString orig,
            Chat.PlayerPickupChatMessage self)
        {
            self.pickupQuantity = Math.Max(1u, self.pickupQuantity);
            return orig(self);
        }

        private static void OnPurchaseDrop(On.RoR2.ShopTerminalBehavior.orig_DropPickup_bool orig, ShopTerminalBehavior self,
            bool isDuplicated)
        {
            Log.Debug("Sharesuite: OnPurchaseDrop triggered");
            if (!NetworkServer.active)
            {
                Log.Debug("Sharesuite: Not server, returning");
                orig(self, isDuplicated);
                return;
            }

            var costType = self.GetComponent<PurchaseInteraction>().costType;
            Log.Debug("Sharesuite: CostType: " + costType);

            //If is valid drop and dupe fix not enabled, true -> we want the item to pop
            //if is valid drop and dupe fix is enabled, false -> item IS shared, we don't want the item to pop, PrinterCauldronFix should deal with this
            //if is not valid drop and dupe fix is not enabled, true -> item ISN'T shared, and dupe fix isn't enabled, we want to pop
            //if is not valid drop and dupe fix is enabled, false -> item ISN'T shared, dupe fix should catch, we don't want to pop

            Log.Debug("Sharesuite: Multiplayer: " + GeneralHooks.IsMultiplayer() + " | ValidItemPickup: " +
                      IsValidItemPickup(self.CurrentPickupIndex()) + " | PrinterCauldronFixEnabled: " +
                      ShareSuite.PrinterCauldronFixEnabled.Value);

            if (!GeneralHooks.IsMultiplayer() // is not multiplayer
                || !IsValidItemPickup(self.CurrentPickupIndex()) && !ShareSuite.PrinterCauldronFixEnabled.Value
                //if it's not a valid drop AND the dupe fix isn't enabled
                || self.itemTier == ItemTier.Lunar
                || costType == CostTypeIndex.Money
                || costType == CostTypeIndex.None)
            {
                Log.Debug("Sharesuite: Origin branch 1");
                orig(self, isDuplicated);
            }
            else if (!ShareSuite.PrinterCauldronFixEnabled.Value && PrinterCosts.Contains(costType))
            {
                Log.Debug("Sharesuite: Origin branch 2");
                orig(self, isDuplicated);
            }
        }

        private static void OnShopPurchase(On.RoR2.PurchaseInteraction.orig_OnInteractionBegin orig,
            PurchaseInteraction self, Interactor activator)
        {
            Log.Debug("Sharesuite: OnShopPurchase triggered");
            if (!self.CanBeAffordedByInteractor(activator)) return;

            if (!GeneralHooks.IsMultiplayer() || self.costType == CostTypeIndex.None)
            {
                orig(self, activator);
                return;
            }

            var shop = self.GetComponent<ShopTerminalBehavior>();

            #region PrinterCauldronfix

            if (PrinterCosts.Contains(self.costType))
            {
                Log.Debug("Sharesuite: PrinterCauldronfix branch");
                if (ShareSuite.PrinterCauldronFixEnabled.Value)
                {
                    var characterBody = activator.GetComponent<CharacterBody>();

                    var inventory = characterBody.inventory;

                    var item = PickupCatalog.GetPickupDef(shop.CurrentPickupIndex())?.itemIndex;

                    if (item == null) Log.Debug("ShareSuite: PickupCatalog is null.");
                    else
                    {
                        Log.Debug("Sharesuite: handling give item");
                        HandleGiveItem(characterBody.master, PickupCatalog.GetPickupDef(shop.CurrentPickupIndex()));
                    }

                    Log.Debug("Sharesuite: orig");
                    orig(self, activator);
                    Log.Debug("Sharesuite: rich cauldron message");
                    ChatHandler.SendRichCauldronMessage(inventory.GetComponent<CharacterMaster>(),
                        shop.CurrentPickupIndex());
                    return;
                }
            }

            #endregion Cauldronfix

            #region EquipmentDronefix

            if (ShareSuite.EquipmentShared.Value)
            {
                if (self.costType == CostTypeIndex.Equipment)
                {
                    Log.Debug("Sharesuite: equipment drone fix thing");
                    //todo check the amount removed is greater than or equal to 1 before doing this

                    orig(self, activator);
                    EquipmentSharingHooks.RemoveAllUnBlacklistedEquipment();
                }
            }

            #endregion

            Log.Debug("Sharesuite: ending orig call");
            orig(self, activator);
        }

        private static void OnScavengerDrop(On.EntityStates.ScavBackpack.Opening.orig_OnEnter orig,
            EntityStates.ScavBackpack.Opening self)
        {
            orig(self);
            ShareSuite.DefaultMaxScavItemDropCount = Math.Max(EntityStates.ScavBackpack.Opening.maxItemDropCount,
                ShareSuite.DefaultMaxScavItemDropCount);
            var chest = self.GetFieldValue<ChestBehavior>("chestBehavior");
            if (chest.tier1Chance > 0.0f)
            {
                var adjustedDrops =
                    Math.Max(
                        (int) Math.Ceiling((double) ShareSuite.DefaultMaxScavItemDropCount /
                                           Run.instance.participatingPlayerCount), 2);
                EntityStates.ScavBackpack.Opening.maxItemDropCount =
                    Math.Min(adjustedDrops, ShareSuite.DefaultMaxScavItemDropCount);
            }
            else
            {
                EntityStates.ScavBackpack.Opening.maxItemDropCount = ShareSuite.DefaultMaxScavItemDropCount;
            }
        }

        //Void Fields item fix
        public static void ArenaDropEnable(ILContext il)
        {
            var cursor = new ILCursor(il);

            cursor.GotoNext(
                x => x.MatchLdloc(1),
                x => x.MatchStloc(out _),
                x => x.MatchLdcR4(out _),
                x => x.MatchLdloc(out _)
            );
            cursor.Index++;
            cursor.EmitDelegate<Func<int, int>>(i => ShareSuite.VoidFieldLootCredit.Value);
        }

        //Simulacrum item fix
        public static void SimulacrumArenaDropEnable(ILContext il)
        {
            var cursor = new ILCursor(il);

            cursor.GotoNext(
                x => x.MatchLdloc(0),
                x => x.MatchStloc(1),
                x => x.MatchLdcR4(out _),
                x => x.MatchLdloc(1)
            );
            cursor.Index++;
            cursor.EmitDelegate<Func<int, int>>(i => ShareSuite.SimulacrumLootCredit.Value);
        }

        public static bool IsValidItemPickup(PickupIndex pickup)
        {
            var pickupDef = PickupCatalog.GetPickupDef(pickup);
            if (pickupDef != null && pickupDef.itemIndex != ItemIndex.None)
            {
                var itemDef = ItemCatalog.GetItemDef(pickupDef.itemIndex);
                switch (itemDef.tier)
                {
                    case ItemTier.Tier1:
                        return ShareSuite.WhiteItemsShared.Value;
                    case ItemTier.Tier2:
                        return ShareSuite.GreenItemsShared.Value;
                    case ItemTier.Tier3:
                        return ShareSuite.RedItemsShared.Value;
                    case ItemTier.Lunar:
                        return ShareSuite.LunarItemsShared.Value;
                    case ItemTier.Boss:
                        return ShareSuite.BossItemsShared.Value;
                    case ItemTier.VoidTier1:
                        return ShareSuite.VoidItemsShared.Value;
                    case ItemTier.VoidTier2:
                        return ShareSuite.VoidItemsShared.Value;
                    case ItemTier.VoidTier3:
                        return ShareSuite.VoidItemsShared.Value;
                    case ItemTier.VoidBoss:
                        return ShareSuite.VoidItemsShared.Value;
                    case ItemTier.NoTier:
                        break;
                    case ItemTier.AssignedAtRuntime:
                        return true;
                    default:
                        return false;
                }
            }

            if (pickupDef != null && pickupDef.equipmentIndex != EquipmentIndex.None)
            {
                // var equipdef = EquipmentCatalog.GetEquipmentDef(pickupdef.equipmentIndex);
                // Optional further checks ...
                return false;
            }

            return false;
        }

        public static event Func<GenericPickupController, CharacterBody, bool> AdditionalPickupValidityChecks;

        public static bool IsValidPickupObject(GenericPickupController pickup, CharacterBody picker)
        {
            if (AdditionalPickupValidityChecks == null)
                return true;
            var retv = true;
            foreach (Func<GenericPickupController, CharacterBody, bool> f in AdditionalPickupValidityChecks
                         .GetInvocationList())
                retv &= f(pickup, picker);
            return retv;
        }

        private static PickupIndex? GetRandomItemOfTier(ItemTier tier, PickupIndex orDefault)
        {
            switch (tier)
            {
                case ItemTier.Tier1:
                    return PickRandomOf(Blacklist.AvailableTier1DropList);
                case ItemTier.Tier2:
                    return PickRandomOf(Blacklist.AvailableTier2DropList);
                case ItemTier.Tier3:
                    return PickRandomOf(Blacklist.AvailableTier3DropList);
                case ItemTier.Lunar:
                    if (ShareSuite.LunarItemsRandomized.Value)
                        return PickRandomOf(Blacklist.AvailableLunarDropList);
                    break;
                case ItemTier.Boss:
                    if (ShareSuite.BossItemsRandomized.Value)
                        return PickRandomOf(Blacklist.AvailableBossDropList);
                    break;
                case ItemTier.VoidBoss:
                    if (ShareSuite.VoidItemsRandomized.Value)
                        return PickRandomOf(Blacklist.AvailableVoidDropList);
                    break;
                case ItemTier.VoidTier1:
                    if (ShareSuite.VoidItemsRandomized.Value)
                        return PickRandomOf(Blacklist.AvailableVoidDropList);
                    break;
                case ItemTier.VoidTier2:
                    if (ShareSuite.VoidItemsRandomized.Value)
                        return PickRandomOf(Blacklist.AvailableVoidDropList);
                    break;
                case ItemTier.VoidTier3:
                    if (ShareSuite.VoidItemsRandomized.Value)
                        return PickRandomOf(Blacklist.AvailableVoidDropList);
                    break;
            }

            var pickupDef = PickupCatalog.GetPickupDef(orDefault);
            if (Blacklist.HasItem(pickupDef.itemIndex))
                return null;
            return orDefault;
        }

        internal static object GetInstanceField(Type type, object instance, string fieldName)
        {
            var bindFlags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic
                            | BindingFlags.Static | BindingFlags.GetField;
            var field = type.GetField(fieldName, bindFlags);
            return field.GetValue(instance);
        }

        internal static void SetInstanceField(Type type, object instance, string fieldName, object value)
        {
            var bindFlags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic
                            | BindingFlags.Static;
            var field = type.GetField(fieldName, bindFlags);
            field.SetValue(instance, value);
        }

        private static T? PickRandomOf<T>(IList<T> collection) where T : struct =>
            collection.Count > 0
                ? collection[Random.Range(0, collection.Count)]
                : (T?) null;

        private static void HandleGiveItem(CharacterMaster characterMaster, PickupDef pickupDef)
        {
            characterMaster.inventory.GiveItem(pickupDef.itemIndex);

            var connectionId = characterMaster.playerCharacterMasterController.networkUser?.connectionToClient
                ?.connectionId;

            if (connectionId != null)
            {
                NetworkHandler.SendItemPickupMessage(connectionId.Value, pickupDef.pickupIndex);
            }
        }

        public static void HandleRichMessageUnlockAndNotification(CharacterMaster characterMaster,
            PickupIndex pickupIndex)
        {
            // No need if rich messages are disabled
            if (!ShareSuite.RichMessagesEnabled.Value || !characterMaster.isLocalPlayer)
            {
                return;
            }

            characterMaster.playerCharacterMasterController?.networkUser?.localUser?.userProfile.DiscoverPickup(
                pickupIndex);

            if (characterMaster.inventory.GetItemCount(PickupCatalog.GetPickupDef(pickupIndex).itemIndex) <= 1)
            {
                CharacterMasterNotificationQueue.PushPickupNotification(characterMaster, pickupIndex);
            }
        }
    }
}
